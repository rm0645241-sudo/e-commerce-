# Cozy Corner Store

A mini e-commerce app built with vanilla JavaScript.

- Products rendered dynamically from a JS array of objects
- Category filter, search and sorting
- Cart with add, +/-, remove, item count, subtotal, 18% GST and total (saved in localStorage)
- Modal checkout preview with form validation and an order confirmation

Run: open `index.html` in a browser. Deploy: GitHub Pages or Vercel.
